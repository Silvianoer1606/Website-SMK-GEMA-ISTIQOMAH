<?php require 'view/header.php'; ?>

<h2 class="text-center" id="margin">Belum ada apa-apa</h2>

<?php require 'view/footer.php'; ?>