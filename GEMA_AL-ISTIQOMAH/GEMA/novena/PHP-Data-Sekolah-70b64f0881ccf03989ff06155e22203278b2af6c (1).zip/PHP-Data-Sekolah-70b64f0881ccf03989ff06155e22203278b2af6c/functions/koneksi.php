<?php
// Koneksi Ke Database
$host = "localhost";
$user = "root";
$pass = "";
$db   = "db_sekolah";

$link = mysqli_connect($host, $user, $pass, $db);

?>