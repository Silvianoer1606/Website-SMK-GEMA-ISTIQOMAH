<?php require 'core/init.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <title>Profile <?= $_SESSION['user']; ?></title>
</head>
<body>
   <h2 align="center">Halaman belum jadi agan <?= $_SESSION['user']; ?></h2>
   <p align="center"><a href="/">Kembali</a></p>
</body>
</html>